<?php

include_once ("conexion.php");

class dt_productos extends Conexion {

private $mycon;

public function listarProductos(){
    try {
        $this->myCon = parent::conectar(); 
        $result = array(); 
        $querySQL = "SELECT * FROM dbkermesse.tbl_productos";
        
        $stm = $this->myCon->prepare($querySQL);
        $stm->execute(); 

        foreach($stm->fetchAll(PDO::FETCH_OBJ) as $r){
            $pt = new producto(); 

            $pt->__SET('id_producto', $r->id_producto);
            $pt->__SET('id_comunidad', $r->id_comunidad);
            $pt->__SET('id_categoria_producto', $r->id_categoria_producto);
            $pt->__SET('nombre_producto', $r->nombre);
            $pt->__SET('descripcion_producto', $r->descripcion); 
            $pt->__SET('cantidad_producto', $r->cantidad);
            $pt->__SET('preciov_sugerido', $r->preciov_sugerido);
            $pt->__SET('estado_producto', $r->estado); 

            $result[] = $pt; 
        }

        $this->myCon = parent::desconectar(); 
        return $result; 

    }catch(Exception $e){
        die($e->getMessage()); 
    }

}



}