<?php

include_once ("conexion.php");

class dt_productos extends Conexion {

private $mycon;

public function listarProductos(){
    try {
        $this->myCon = parent::conectar(); 
        $result = array(); 
        $querySQL = "SELECT * FROM dbkermesse.tbl_productos";
        
        $stm = $this->myCon->prepare($querySQL);
        $stm->execute(); 

        foreach($stm->fetchAll(PDO::FETCH_OBJ) as $r){
            $pt = new producto(); 

            $pt->__SET('id_producto', $r->id_producto);
            $pt->__SET('id_comunidad', $r->id_comunidad);
            $pt->__SET('id_cat_producto', $r->id_cat_producto);
            $pt->__SET('nombre', $r->nombre);
            $pt->__SET('descripcion', $r->descripcion); 
            $pt->__SET('cantidad', $r->cantidad);
            $pt->__SET('preciov_sugerido', $r->preciov_sugerido);
            $pt->__SET('estado', $r->estado); 

            $result[] = $pt; 
        }

        $this->myCon = parent::desconectar(); 
        return $result; 

    }catch(Exception $e){
        die($e->getMessage()); 
    }

}



}