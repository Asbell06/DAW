<?php

include_once ("conexion.php");

class dt_control_bonos extends Conexion {

private $mycon;

public function listarControlBonos(){
    try {
        $this->myCon = parent::conectar(); 
        $result = array(); 
        $querySQL = "SELECT * FROM dbkermesse.tbl_control_bonos";
        
        $stm = $this->myCon->prepare($querySQL);
        $stm->execute(); 

        foreach($stm->fetchAll(PDO::FETCH_OBJ) as $r){
            $cb = new control_bonos(); 

            $cb->__SET('id_bono', $r->id_control_bono);
            $cb->__SET('bono', $r->bono);
            $cb->__SET('nombre', $r->nombre);
            $cb->__SET('valor', $r->valor);
            $cb->__SET('estado', $r->estado); 

            $result[] = $cb; 
        }

        $this->myCon = parent::desconectar(); 
        return $result; 

    }catch(Exception $e){
        die($e->getMessage()); 
    }

}



}