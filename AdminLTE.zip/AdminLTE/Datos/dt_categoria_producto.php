<?php

include_once ("conexion.php");

class dt_categoria_producto extends Conexion {

private $mycon;

public function listarCategoriaProducto(){
    try {
        $this->myCon = parent::conectar(); 
        $result = array(); 
        $querySQL = "SELECT * FROM dbkermesse.tbl_productos";
        
        $stm = $this->myCon->prepare($querySQL);
        $stm->execute(); 

        foreach($stm->fetchAll(PDO::FETCH_OBJ) as $r){
            $cpt = new categoria_producto(); 

            $cpt->__SET('id_categoria_producto', $r->id_categoria_producto);
            $cpt->__SET('nombre', $r->nombre);
            $cpt->__SET('descripcion', $r->descripcion); 
            $cpt->__SET('estado', $r->estado); 

            $result[] = $cpt; 
        }

        $this->myCon = parent::desconectar(); 
        return $result; 

    }catch(Exception $e){
        die($e->getMessage()); 
    }

}



}